const frame = document.querySelector('#frame');
const count = document.querySelector('#count');
const selected = new Set();
function render() {
  for (const [index, button] of [...frame.children].entries()) {
    button.setAttribute('aria-pressed', String(selected.has(index)));
    button.textContent = selected.has(index) ? '⭐' : '';
  }
  count.textContent = `${selected.size} + ${10 - selected.size} = 10`;
}
for (let index = 0; index < 10; index += 1) {
  const button = document.createElement('button');
  button.className = 'cell';
  button.setAttribute('aria-label', `${index + 1}번째 칸`);
  button.addEventListener('click', () => {
    if (selected.has(index)) selected.delete(index);
    else selected.add(index);
    render();
  });
  frame.append(button);
}
document.querySelector('#clear').addEventListener('click', () => { selected.clear(); render(); });
render();
