export function describeSum(left, right, answer) {
  return `${left}개에 ${right}개를 더하면 ${answer}개!`;
}
