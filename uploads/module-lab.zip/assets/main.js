const status = document.querySelector('#status');
const calculate = document.querySelector('#calculate');
const checks = document.querySelector('#checks');
function checked(text) { const item = document.createElement('li'); item.textContent = `✓ ${text}`; checks.append(item); }
try {
  const [{ describeSum }, lesson, wasmBytes] = await Promise.all([
    import('./chunks/describe.js'),
    fetch(new URL('./lesson.json', import.meta.url)).then((response) => { if (!response.ok) throw new Error('JSON not found'); return response.json(); }),
    fetch(new URL('./add.wasm', import.meta.url)).then((response) => { if (!response.ok) throw new Error('WASM not found'); return response.arrayBuffer(); }),
  ]);
  checked('동적 JavaScript 모듈'); checked(`JSON 데이터: ${lesson.name}`);
  const { instance } = await WebAssembly.instantiate(wasmBytes);
  checked('WebAssembly 계산 함수');
  function update() {
    const left = Math.max(0, Math.min(50, Number(document.querySelector('#left').value) || 0));
    const right = Math.max(0, Math.min(50, Number(document.querySelector('#right').value) || 0));
    const answer = instance.exports.add(left, right);
    document.querySelector('#answer').textContent = String(answer);
    status.textContent = describeSum(left, right, answer);
  }
  calculate.disabled = false;
  calculate.addEventListener('click', update);
  update();
} catch (error) { status.textContent = `파일 확인 필요: ${error.message}`; }
const audio = new Audio(new URL('./tone.wav', import.meta.url).href);
document.querySelector('#sound').addEventListener('click', async () => {
  const message = document.querySelector('#sound-status');
  try { audio.currentTime = 0; await audio.play(); message.textContent = 'WAV 파일을 재생했어요.'; }
  catch { message.textContent = '소리 재생을 허용한 뒤 다시 눌러 주세요.'; }
});
